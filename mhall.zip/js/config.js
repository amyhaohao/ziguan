var config = {
//    api: 'http://101.226.207.142:9080/mhall-web-server/',
//    api: 'http://192.168.6.68:9008/mhall-web-server/',
//1996
//    api: 'http://222.73.184.62:8111/mhall-web-server/',
    //银河
//    api: 'http://210.12.39.49:8111/mhall-web-server/',
    api:"http://180.169.30.6:10229/mhall-web-server/",
//    api:"http://www.my.com/mocker/",
//    api:"http://101.231.162.60:8111/mhall-web-server/",
   
//    video: "pobo:pageId=900005&uncheck=1&wk=1&url=web1/modules/video/index.html#/", 
//    signature: "pobo:pageId=900005&uncheck=1&wk=1&orientation=1&url=web1/modules/adequacySignature/index.html#/",
//    
//    loginType:"sms", //trade, sms, smstrade
    secureKeyboard:1,
//    banners:[{img:"images/banner1.png"},{img:"images/banner2.jpg"},{img:"images/banner3.jpg"}],
    biz:{
        phone:{code:"phone_num_change"},
        id:{code:"card_validate_change"},
        address:{code:"address_change"},
        address2:{code:"permanentAddress"},
        email:{code:"email_change"},
        bank:{code:"bank_settlement_accounts_change"},
        trade:{code:"trade_system_change"},
        active:{code:""},
        simulate:{name: "仿真账号申请", code:""},
        pass:{code:"password_reset"},
        adequacy:{code:"adequacy", url:"pobo:uncheck=1&pageId=900005&wk=1&url=web1/modules/adequacyOnMhall/index.html"},
        agreement:{code:"agreement_sign"},
        info:{code:"base_info_change"},
    },  
    
//    imgMaxWidthHeight: 1500,
//    imgRatio: 0.7,
//    
//    expireDays: 90,
//    ocrId:1,
//    nologin:1
}
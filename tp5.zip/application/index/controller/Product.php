<?php
namespace app\index\controller;

use think\Db;

class Product
{
    public static $reg = "/'|%|\?|\*|\\\|\//";
    
    public function index($page, $name, $cat, $sort, $flag)
    {
        if($page<1 || preg_match(self::$reg, $name) || preg_match(self::$reg, $cat))  
            return json("", 400);
        
        $where = "";
        $catWhere = "";
        $orderBy = "";
        if($name) {
            $where = $catWhere = "product_name like '%".$name."%' or product_cat like '%".$name."%'";
        }
        if($cat) {
            if($where)
                $where = "(".$where.") and ";
            $where = $where."product_cat like '%".$cat."%'";
        }
        if($where)
            $where = 'where '.$where;
        if($sort==1)
            $orderBy = ' order by product_price2 asc';
        if($sort==2)
            $orderBy = ' order by product_sales desc';
        $total = Db::query('select count(*) as c from products '.$where);
        $total = $total[0]['c'];
        $pages = ceil($total/20);
        if($page>$pages)
            $page = $pages;
        
        $result = [];
        $cats = [];
        
        if($total>0) {
            $result = Db::query('select product_id as pid, product_name as pname, product_img as img, product_link as plink, product_price as price, product_price2 as price2, product_sales as sale, coupon_id as cid, coupon_cond as cond, coupon_discount as disc, coupon_link as clink from products '.$where.$orderBy.' limit '.(($page-1)*20).', 20');
        
            if($flag==1 && $name) {
                $result2 = Db::query('select distinct product_cat as cat from products where '.$catWhere);
                foreach($result2 as $d){
                    $d = explode('/', $d['cat']);
                    foreach($d as $c)
                        if(!in_array($c, $cats))
                            $cats[] = $c;
                }
            }
        }
        
        return json(['code'=>0, 'data'=>$result, 'total'=>$total, 'cats'=>$cats]);
    }
    
    public function updateCat($cat)
    {
        if(preg_match(self::$reg, $cat))  
            return json(['code'=>0]);
        Db::execute("update cats set total = total+1 where name = '".$cat."'");
        return json(['code'=>0]);
    }
    
    public function cats()
    {
        $result = Db::query('select name from cats order by total desc');
        $result2 = [];
        foreach($result as $d)
            $result2[] = $d['name'];
        return json(['code'=>0, 'data'=>$result2]);
    }
    
    public function coupon($cat, $page){
        if($page<1 || preg_match(self::$reg, $cat))  
            return json("", 400);
        
        $offset = ($page-1)*20;
        $result = Db::query("select product_name, product_link, coupon_name, coupon_link from products where product_cat like '%".$cat."%' limit ".$offset.", 20");
        $total = Db::query("select count(*) as c from products where product_cat like '%".$cat."%'");
        
        $html = '<!DOCTYPE html><html>
        <head><title>'.$cat.'优惠券</title>
    <meta name="keywords" content="优惠券,'.$cat.'"/>
    <meta name="description" content="提供淘宝天猫优惠券领取"/>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <style>a{margin:0 10px;}</style>
    <script src="/js/j.js"></script>
    </head><body><noscript>为了您更好的用户体验，请打开Javascript设置。</noscript>';
        
        foreach($result as $d)
            $html = $html.'<a href="'.$d['product_link'].'" target="_blank">'.$d['product_name'].'</a><a href="'.$d['coupon_link'].'&pid=mm_15625019_4770794_15114258" target="_blank">'.$d['coupon_name'].'</a>';
        
        if($total[0]['c']>$offset+20)
            $html = $html.'<a href="'.($page+1).'.html">下一页</a>';
        
        return $html.'</body></html>';
    }
}

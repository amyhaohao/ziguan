<?php
namespace app\statistic\controller;

use think\Db;

class Index
{
    public function import($data, $mode)
    {
        $result = Db::query('select name from statistic');
        $result2 = array();
        foreach($result as $d){
            $result2[$d['name']] = 0;
        }
        foreach($data as $k=>$d){
            if(array_key_exists($k, $result2)) {
                if($mode)
                    Db::execute('update statistic set success = success+?, fail = fail+?, time = ? where name = ?', [$d[0], $d[1], $d[2], $k]);
                else
                    Db::execute('update statistic set success = ?, fail = ?, time = ? where name = ?', [$d[0], $d[1], $d[2], $k]);
            } else
                Db::execute('insert into statistic (name, success, fail, time) values(?,?,?,?)', [$k, $d[0], $d[1], $d[2]]);
        }
        return json(['code'=>0]);
    }
    
    public function index()
    {
//        $result = Db::query('select name from statistic');
//        $result2 = array();
//        foreach($result as $d){
//            $result2[$d['name']] = 0;
//        }
        dump(2==true);
    }
}

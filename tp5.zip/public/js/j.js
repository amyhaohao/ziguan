var l=location,a=l.href.match(/coupon\/(.+?)\/(\d+)/);if(a) sessionStorage.query=JSON.stringify({cat:decodeURIComponent(a[1]),page:a[2], j:1});
l.href="/";
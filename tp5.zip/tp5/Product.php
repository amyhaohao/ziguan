<?php
namespace app\index\controller;

use think\Db;

class Product
{
//    public static $reg = "/'|%|\?|\*|\\\\|\//";
    public static $reg = "/'|\\\\|\//";
    
    public static $pagesize = 60;
    
    public function replace($a){
        $a = str_replace('\\', '\\\\\\\\', $a);
        $a = str_replace(["'","%","_","[","]","^","!"], ["\\'","\\\\%","\\\\_","\\\\[","\\\\]","\\\\^","\\\\!"], $a);
        return $a;
    }
    
    public function index($page, $name, $pcat, $cat, $sort, $flag)
    {
//        preg_match(self::$reg, $cat)
        if($page<1)  
            return json("", 400);
        
        $where = "";
        $catWhere = "";
        $orderBy = "";
        if(strlen($name)) {
            $name = $this->replace($name);
            $where = $catWhere = "where product_name like '%".$name."%'";
        }else {
            if($pcat<1)
                return json("", 400);
            $where = "where product_pcat = ".$pcat;
        }
        if($cat>0)
            $where = $where." and product_cat = ".$cat;

        if($sort==1)
            $orderBy = ' order by product_price2 asc';
        else if($sort==2)
            $orderBy = ' order by product_sales desc';
        else 
            $orderBy = ' order by id desc';
        $total = Db::query('select count(*) as c from products '.$where);
        $total = $total[0]['c'];
        $pages = ceil($total/self::$pagesize);
        if($page>$pages)
            $page = $pages;
        
        $result = [];
        $cats = [];
        
        if($total>0) {
            $result = Db::query('select product_name as pn, product_img as pi, product_link as pl, product_price as pp, product_price2 as pp2, product_sales as ps, coupon_cond as cc, coupon_discount as cd, coupon_link as cl from products '.$where.$orderBy.' limit '.(($page-1)*self::$pagesize).', '.self::$pagesize);
        
            if($flag==1 && strlen($name)) {
                $result2 = Db::query('select distinct product_cat as cat from products '.$catWhere);
                foreach($result2 as $d){
//                    $d = explode('/', $d['cat']);
//                    foreach($d as $c)
//                        if(!in_array($c, $cats))
//                            $cats[] = $c;
                    $cats[] = $d['cat'];
                }
            }
        }
        
        return json(['code'=>0, 'data'=>$result, 'total'=>$total, 'cats'=>$cats]);
    }
    
    public function updateCat($cat)
    {
        if($cat<1)  
            return json(['code'=>0]);
        Db::execute("update cats set total = total+1 where id = ".$cat);
        return json(['code'=>0]);
    }
    
    public function cats()
    {
        $result = Db::query('select id, pid, name from cats order by total');
        return json(['code'=>0, 'data'=>$result]);
    }
    
    public function coupon($cat, $page, $n){
        if($page<1 || $page>10 || $cat<1)  
            return json("", 400);
        
        $offset = ($page-1)*self::$pagesize;
        $total = Db::query("select count(*) as c from products where product_cat = ".$cat);
        $total = $total[0]['c'];
        $result = [];
        if($total>$offset)
            $result = Db::query("select product_name, product_link, coupon_name, coupon_link from products where product_cat = ".$cat." order by id desc limit ".$offset.", ".self::$pagesize);
        
        
        $html = '<!DOCTYPE html><html>
        <head><title>'.$n.'优惠券</title>
    <meta name="keywords" content="'.$n.'优惠券"/>
    <meta name="description" content="提供淘宝天猫优惠券领取"/>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <style>a{margin:0 10px;}</style>
    <script src="/js/j.js"></script>
    </head><body><noscript>为了您更好的用户体验，请打开Javascript设置。</noscript>';
        
        foreach($result as $d)
            $html = $html.'<a href="'.$d['product_link'].'" target="_blank">'.$d['product_name'].'</a><a href="'.$d['coupon_link'].'&pid=mm_15625019_4770794_15114258" target="_blank">'.$d['coupon_name'].'</a>';
        
        if($page<10 && $total>$offset+self::$pagesize)
            $html = $html.'<a href="'.($page+1).'.html?n='.$n.'">下一页</a>';
        
        return $html.'</body></html>';
    }
}

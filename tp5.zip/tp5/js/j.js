var l=location,a=l.href.match(/coupon\/(\d+)\/(\d+)\/(\d+)/);if(a) sessionStorage.query=JSON.stringify({cat:a[1],pcat:a[2],page:a[3],j:1});
l.href="/";
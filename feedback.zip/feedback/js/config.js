var config = {
    api: 'http://192.168.6.119:8080/pobo_feedback_manager/',
    infoPath: '../pobo_info_manager/',
}